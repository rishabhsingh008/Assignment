package assignment.rishabh.com.topgithubrishabh.view

import android.content.Intent
import android.databinding.DataBindingUtil
import android.databinding.ViewDataBinding
import android.os.Bundle
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import assignment.rishabh.com.topgithubrishabh.R
import assignment.rishabh.com.topgithubrishabh.model.bind_adapter.BindableAdapter
import assignment.rishabh.com.topgithubrishabh.model.pojo.GitHubUser
import com.android.databinding.library.baseAdapters.BR
import kotlinx.android.synthetic.main.list_item.view.*


class UserListAdapter : RecyclerView.Adapter<UserListAdapter.UserHolder>(), BindableAdapter<GitHubUser> {

    override fun setData(items: List<GitHubUser>) {
        userList = items
        notifyDataSetChanged()
    }

    var userList: List<GitHubUser> = mutableListOf()


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): UserHolder {
        val inflater = LayoutInflater.from(parent.context)
        return UserHolder(DataBindingUtil.inflate(inflater, R.layout.list_item, parent, false))
    }

    override fun getItemCount() = userList.size

    override fun onBindViewHolder(holder: UserHolder, position: Int) {
        holder.bind(userList[position])
    }

    class UserHolder(itemView: ViewDataBinding) : RecyclerView.ViewHolder(itemView.root) {

        private var viewDataBinding: ViewDataBinding? = itemView

        fun bind(user: GitHubUser) {
            viewDataBinding?.setVariable(BR.gituser,user)
            viewDataBinding?.executePendingBindings()

            viewDataBinding?.root?.itemLayout?.setOnClickListener{
                var i = Intent(it.context, UserDetailsActivity::class.java)
                var b = Bundle()
                b.putParcelable("userdata", user)
                i.putExtras(b)
                it.context.startActivity(i)
            }

        }
    }

}