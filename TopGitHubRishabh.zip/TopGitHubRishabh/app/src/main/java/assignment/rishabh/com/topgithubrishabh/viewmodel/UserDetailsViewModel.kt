package assignment.rishabh.com.topgithubrishabh.viewmodel

import android.databinding.BaseObservable
import android.databinding.Bindable

import assignment.rishabh.com.topgithubrishabh.model.pojo.GitHubUser
import com.android.databinding.library.baseAdapters.BR

class UserDetailsViewModel : BaseObservable() {

    @get:Bindable
    var gitUser: GitHubUser? = GitHubUser()

    fun setData(user: GitHubUser?) {
        gitUser = user
        notifyPropertyChanged(BR.gitUser)
    }
}
