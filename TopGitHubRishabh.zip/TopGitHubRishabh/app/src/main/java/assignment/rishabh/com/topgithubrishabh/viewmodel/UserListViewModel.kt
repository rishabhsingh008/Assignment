package assignment.rishabh.com.topgithubrishabh.viewmodel

import android.content.Context
import android.databinding.BaseObservable
import android.databinding.Bindable
import android.widget.Toast
import assignment.rishabh.com.topgithubrishabh.model.networking.RetrofitFactory
import assignment.rishabh.com.topgithubrishabh.model.Utility
import assignment.rishabh.com.topgithubrishabh.model.pojo.GitHubUser
import com.android.databinding.library.baseAdapters.BR
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class UserListViewModel : BaseObservable() {

    var c : Context?= null

    @get:Bindable
    var userList: List<GitHubUser>? = mutableListOf()
        private set(value) {
            field = value
            notifyPropertyChanged(BR.userList)
        }

    fun startFetchingUserList(c : Context) {
        this.c = c
        if(Utility.isNetworkConnected(c))
            fetchTopGitHubUsersList()
        else
            Toast.makeText(c,"Please connect to internet",Toast.LENGTH_SHORT).show();
    }

    fun fetchTopGitHubUsersList(){
        val service = RetrofitFactory.makeRetrofitService()
        CoroutineScope(Dispatchers.IO).launch {
            val response = service.doGetUserList("java", "weekly")
            if (response!=null && response.isSuccessful) {
                userList = response.body()?.orEmpty()
            }
        }
    }
}