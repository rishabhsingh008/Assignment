package assignment.rishabh.com.topgithubrishabh.model

import android.content.Context
import android.net.ConnectivityManager

object Utility {

    internal fun isNetworkConnected(c: Context): Boolean {
        val cm = c.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        return cm.activeNetworkInfo != null
    }
}
