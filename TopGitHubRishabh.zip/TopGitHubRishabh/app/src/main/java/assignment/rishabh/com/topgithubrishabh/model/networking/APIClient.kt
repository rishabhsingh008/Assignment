package assignment.rishabh.com.topgithubrishabh.model.networking

import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory

object RetrofitFactory {
    const val BASE_URL = "https://github-trending-api.now.sh"

    fun makeRetrofitService(): APIInterface {
        return Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addConverterFactory(MoshiConverterFactory.create())
                .build().create(APIInterface::class.java)
    }
}
