package assignment.rishabh.com.topgithubrishabh.model.bind_adapter

interface BindableAdapter<T> {
    fun setData(items: List<T>)
}