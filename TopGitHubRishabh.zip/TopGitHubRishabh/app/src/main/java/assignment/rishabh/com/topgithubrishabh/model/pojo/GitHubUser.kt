package assignment.rishabh.com.topgithubrishabh.model.pojo

import android.databinding.BaseObservable
import android.databinding.Bindable
import android.os.Parcel
import android.os.Parcelable
import android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE
import com.android.databinding.library.baseAdapters.BR
import com.google.gson.annotations.SerializedName

class GitHubUser() : BaseObservable(),Parcelable{

    @Bindable
    @SerializedName("username")
    var username: String? = null
    @SerializedName("type")
    var type: String? = null
    @Bindable
    @SerializedName("url")
    var url: String? = null
    @Bindable
    @SerializedName("avatar")
    var avatar: String? = null
    @Bindable
    @SerializedName("repo")
    var repo = RepoData()

    @Bindable
    var selected: Boolean = false

    constructor(parcel: Parcel) : this() {
        username = parcel.readString()
        type = parcel.readString()
        url = parcel.readString()
        avatar = parcel.readString()
        selected = parcel.readByte() != 0.toByte()
        repo = RepoData.createFromParcel(parcel)
    }

    class RepoData() : BaseObservable(),Parcelable{
        @Bindable
        @SerializedName("name")
        var name: String? = null
        @Bindable
        @SerializedName("description")
        var description: String? = null
        @Bindable
        @SerializedName("url")
        var url: String? = null

        constructor(parcel: Parcel) : this() {
            name = parcel.readString()
            description = parcel.readString()
            url = parcel.readString()
        }

        override fun writeToParcel(parcel: Parcel, flags: Int) {
            parcel.writeString(name)
            parcel.writeString(description)
            parcel.writeString(url)
        }

        override fun describeContents(): Int {
            return 0
        }

        companion object CREATOR : Parcelable.Creator<RepoData> {
            override fun createFromParcel(parcel: Parcel): RepoData {
                return RepoData(parcel)
            }

            override fun newArray(size: Int): Array<RepoData?> {
                return arrayOfNulls(size)
            }
        }

    }

    fun itemSelected() = {
        selected = true
        notifyPropertyChanged(BR.selected);
    }

    override fun writeToParcel(parcel: Parcel, flags: Int) {
        parcel.writeString(username)
        parcel.writeString(type)
        parcel.writeString(url)
        parcel.writeString(avatar)
        parcel.writeByte(if (selected) 1 else 0)
        parcel.writeParcelable(repo,PARCELABLE_WRITE_RETURN_VALUE)
    }

    override fun describeContents(): Int {
        return 0
    }

    companion object CREATOR : Parcelable.Creator<GitHubUser> {
        override fun createFromParcel(parcel: Parcel): GitHubUser {
            return GitHubUser(parcel)
        }

        override fun newArray(size: Int): Array<GitHubUser?> {
            return arrayOfNulls(size)
        }
    }
}
