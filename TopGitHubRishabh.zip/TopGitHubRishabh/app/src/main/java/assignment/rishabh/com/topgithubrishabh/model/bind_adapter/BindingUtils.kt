package assignment.rishabh.com.topgithubrishabh.model.bind_adapter

import android.databinding.BindingAdapter
import android.support.v7.widget.RecyclerView
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import com.squareup.picasso.Picasso

@BindingAdapter("data")
fun <T> setRecyclerViewProperties(recyclerView: RecyclerView, items: List<T>) {
    if (recyclerView.adapter is BindableAdapter<*>) {
        (recyclerView.adapter as BindableAdapter<T>).setData(items)
    }
}

@BindingAdapter("data")
fun <T> setProgressBarProperties(progressBar: ProgressBar, items: List<T>) {
    if (items.size>0)
        progressBar.visibility = View.GONE
}

@BindingAdapter("android:src")
fun setImageUrl(view: ImageView, url: String) {
    Picasso.get().load(url).into(view);
}
