package assignment.rishabh.com.topgithubrishabh.view

import android.databinding.DataBindingUtil
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import assignment.rishabh.com.topgithubrishabh.R
import assignment.rishabh.com.topgithubrishabh.viewmodel.UserDetailsViewModel

class UserDetailsActivity: AppCompatActivity() {

    private val viewModel = UserDetailsViewModel()
    private final val USER_DATA_KEY="userdata"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding: assignment.rishabh.com.topgithubrishabh.databinding.UserDetailsLayoutBinding = DataBindingUtil.setContentView(this, R.layout.user_details_layout)
        binding.viewmodel = viewModel
        viewModel.setData(intent.getParcelableExtra(USER_DATA_KEY))


    }
}