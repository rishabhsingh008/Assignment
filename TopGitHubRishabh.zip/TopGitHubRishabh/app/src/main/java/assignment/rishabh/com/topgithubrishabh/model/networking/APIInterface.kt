package assignment.rishabh.com.topgithubrishabh.model.networking


import assignment.rishabh.com.topgithubrishabh.model.pojo.GitHubUser
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface APIInterface {

    @GET("/developers?")
    suspend fun doGetUserList(@Query("language") language: String, @Query("since") weekly: String): Response<List<GitHubUser>>

}
