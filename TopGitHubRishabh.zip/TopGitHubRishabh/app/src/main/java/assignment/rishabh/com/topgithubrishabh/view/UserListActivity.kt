package assignment.rishabh.com.topgithubrishabh.view

import android.databinding.DataBindingUtil
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import assignment.rishabh.com.topgithubrishabh.R
import assignment.rishabh.com.topgithubrishabh.viewmodel.UserListViewModel
import kotlinx.android.synthetic.main.activity_main.*

class UserListActivity : AppCompatActivity() {



    private val viewModel = UserListViewModel()
    val adapter = UserListAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val binding: assignment.rishabh.com.topgithubrishabh.databinding.ActivityMainBinding = DataBindingUtil.setContentView(this, R.layout.activity_main)
        progressBar.visibility = View.VISIBLE
        recyclerView.adapter = adapter

        binding.viewmodel = viewModel
        viewModel.startFetchingUserList(this)
    }
}
